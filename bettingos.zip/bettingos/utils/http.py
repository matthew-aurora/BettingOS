from __future__ import annotations
import json
from pathlib import Path
from urllib.parse import urlparse
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from ..config import SETTINGS
from .circuits import CircuitBreaker

ETAG_CACHE = Path(".etag_cache.json")
_circuit = CircuitBreaker()

_headers = {"User-Agent": SETTINGS.user_agent, "Accept-Encoding": "gzip, deflate"}

if ETAG_CACHE.exists():
    _etags = json.loads(ETAG_CACHE.read_text())
else:
    _etags = {}

def _save_cache():
    ETAG_CACHE.write_text(json.dumps(_etags))

def _domain(url: str) -> str:
    return urlparse(url).netloc

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=10))
def fetch(url: str, timeout: float = 10.0) -> httpx.Response:
    dom = _domain(url)
    if not _circuit.allow(dom):
        raise RuntimeError(f"Circuit open for {dom}")

    headers = dict(_headers)
    etag = _etags.get(url)
    if etag:
        headers["If-None-Match"] = etag

    try:
        with httpx.Client(timeout=timeout, follow_redirects=True, headers=headers) as c:
            r = c.get(url)
    except Exception:
        _circuit.record_failure(dom)
        raise

    if r.status_code in (429, 500, 502, 503, 504):
        _circuit.record_failure(dom)
    if r.status_code == 304:
        r._content = b""  # type: ignore[attr-defined]
        return r

    et = r.headers.get("ETag")
    if et:
        _etags[url] = et
        _save_cache()
    return r
