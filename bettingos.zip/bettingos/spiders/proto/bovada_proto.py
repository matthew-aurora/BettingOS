from __future__ import annotations
import os
import json
import requests
import yaml

from ...config import SETTINGS
from ...db.mongo import insert_snapshot
from ...mappers.bovada import map_event

BOOKMAKER = "bovada"

# Turn on verbose debug by setting: $env:BOVADA_DEBUG="1"
VERBOSE = os.getenv("BOVADA_DEBUG", "0") not in ("0", "false", "False")

HEADERS = {
    "User-Agent": SETTINGS.user_agent,
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.bovada.lv/",
    "Origin": "https://www.bovada.lv",
}

def _dbg(msg: str) -> None:
    if VERBOSE:
        print(f"[bovada] {msg}")

def fetch_json(url: str):
    try:
        r = requests.get(url, timeout=15, headers=HEADERS)
        ct = r.headers.get("Content-Type", "")
        text = r.text
        _dbg(f"GET {url} -> {r.status_code} ({len(text)} bytes, ct={ct})")
        r.raise_for_status()
        try:
            return r.json()
        except Exception:
            # Some endpoints send JSON with atypical headers; try manual load
            return json.loads(text)
    except Exception as e:
        _dbg(f"ERROR fetching {url}: {e}")
        return None

def _iter_events(payload):
    """Yield event dicts from a variety of Bovada shapes."""
    if payload is None:
        return
    if isinstance(payload, list):
        for item in payload:
            yield from _iter_events(item)
        return
    if isinstance(payload, dict):
        # direct list of events
        evs = payload.get("events")
        if isinstance(evs, list) and evs:
            for ev in evs:
                yield ev
        # nested collections
        for key in ("data", "items", "leagues", "sports", "groups"):
            val = payload.get(key)
            if isinstance(val, list):
                for v in val:
                    yield from _iter_events(v)
        # single event heuristic
        if "displayGroups" in payload and "id" in payload:
            yield payload

def run_once() -> int:
    # 1) Load registry
    try:
        cfg = yaml.safe_load(open("books.yaml", "r", encoding="utf-8")) or {}
    except Exception as e:
        _dbg(f"Could not read books.yaml: {e}")
        return 0

    book = next((b for b in cfg.get("books", []) if b.get("key") == BOOKMAKER and b.get("enabled")), None)
    if not book:
        _dbg("Book not enabled or missing in books.yaml")
        return 0

    feeds = (book.get("proto") or {}).get("feeds") or []
    if not feeds:
        _dbg("No proto.feeds configured")
        return 0

    # 2) Pull each feed and normalize
    total = 0
    for feed in feeds:
        sport = str(feed.get("sport") or "")
        league = str(feed.get("league") or "")
        url = str(feed.get("url") or "").strip()
        if not url:
            continue

        payload = fetch_json(url)
        ev_count = 0
        snap_count = 0

        for evt in _iter_events(payload):
            ev_count += 1
            snaps = map_event(evt, bookmaker=BOOKMAKER, sport=sport, league=league, source_url=url)
            for s in snaps:
                insert_snapshot(s.doc())
                total += 1
                snap_count += 1

        _dbg(f"feed sport={sport} league={league} -> events={ev_count}, snaps={snap_count}")

    _dbg(f"total snapshots inserted: {total}")
    return total
