# bettingos/cli.py

from __future__ import annotations
import argparse
from datetime import datetime, timezone
from pprint import pprint
import yaml

from .config import SETTINGS
from .db.mongo import ensure_indices, get_db
from .ev.calc import de_vig_three_way, ev_decimal
from .ev.arbit import is_three_way_arb, is_two_way_arb
from .scheduler.run_scheduler import main as scheduler_main
from .utils.robots import fetch_and_store

# Direct (non-lazy) imports of protos
from .spiders.proto import bovada_proto
from .spiders.proto import cloudbet_proto
from .spiders.proto import browser_proto  # Playwright harvester


# --- helper: ensure datetime is timezone-aware (UTC) ---
def _as_aware(dt):
    """Treat naive datetimes as UTC; keep aware datetimes unchanged."""
    return dt if getattr(dt, "tzinfo", None) else dt.replace(tzinfo=timezone.utc)


# ------------------- Commands ------------------- #

def cmd_init_db(args):
    ensure_indices()
    print("Indices ensured.")


def cmd_proto_scrape(args):
    """
    Prototype runners per book.
      - bovada
      - cloudbet
      - (optional) --browser <book> to use the generic Playwright harvester
    """
    if getattr(args, "browser", False):
        n = browser_proto.run_once(args.book)
    elif args.book == "bovada":
        n = bovada_proto.run_once()
    elif args.book == "cloudbet":
        n = cloudbet_proto.run_once()
    else:
        print(f"Unknown book '{args.book}'. Try: bovada | cloudbet | --browser <book>")
        return 2
    print(f"Inserted {n} snapshots.")


def cmd_scheduler(args):
    scheduler_main()


def _ev_scan_print(ev_threshold: float) -> None:
    """
    Latest-snapshot EV scan that supports both 3-way (FT_1X2) and 2-way (FT_ML_2W).
    """
    db = get_db()
    coll = db.get_collection("quotes_snapshots")

    pipeline = [
        {"$match": {"market_uid": {"$in": ["FT_1X2", "FT_ML_2W"]}}},
        {"$sort": {"captured_at_utc": -1}},
        {"$group": {"_id": {"event": "$event_key", "selection": "$selection"},
                    "doc": {"$first": "$$ROOT"}}},
        {"$group": {"_id": "$_id.event", "rows": {"$push": "$doc"}}},
    ]

    for row in coll.aggregate(pipeline):
        rows = row["rows"]
        labels = {r["selection"] for r in rows}
        # Prefer 3-way if present
        if {"home", "draw", "away"}.issubset(labels):
            od = {r["selection"]: r["odds_decimal"] for r in rows if r["selection"] in {"home", "draw", "away"}}
            probs = de_vig_three_way([od["home"], od["draw"], od["away"]])
            for sel, p in zip(["home", "draw", "away"], probs):
                ev = ev_decimal(p, od[sel])
                if ev >= ev_threshold:
                    print(f"EV hit: event={row['_id']} sel={sel} odds={od[sel]:.2f} EV={ev*100:.2f}%")
        # Else fall back to 2-way
        elif {"home", "away"}.issubset(labels):
            od = {r["selection"]: r["odds_decimal"] for r in rows if r["selection"] in {"home", "away"}}
            inv = [1.0 / od["home"], 1.0 / od["away"]]
            s = sum(inv)
            probs = [x / s for x in inv]  # home, away
            for sel, p in zip(["home", "away"], probs):
                ev = ev_decimal(p, od[sel])
                if ev >= ev_threshold:
                    print(f"EV hit: event={row['_id']} sel={sel} odds={od[sel]:.2f} EV={ev*100:.2f}%")
        else:
            continue


def cmd_ev_scan(args):
    _ev_scan_print(args.edge)


def cmd_ev_scan_xbook(args):
    """
    Cross-book best price EV + arb detection.
    Supports 3-way (FT_1X2) and 2-way (FT_ML_2W).
    Persists EV hits into ev_hits.
    """
    db = get_db()
    coll = db.get_collection("quotes_snapshots")
    ev_coll = db.get_collection("ev_hits")

    pipeline = [
        {"$match": {"market_uid": {"$in": ["FT_1X2", "FT_ML_2W"]}}},
        {"$sort": {"odds_decimal": -1, "captured_at_utc": -1}},
        {"$group": {"_id": {"event": "$event_key", "selection": "$selection"},
                    "doc": {"$first": "$$ROOT"}}},
        {"$group": {"_id": "$_id.event", "rows": {"$push": "$doc"}}},
    ]

    hits = 0
    now = datetime.now(timezone.utc)
    stale_s = SETTINGS.stale_s
    min_books = SETTINGS.min_books_for_consensus  # coarse gate

    for row in coll.aggregate(pipeline):
        rows = row["rows"]

        # Filter by freshness
        fresh = []
        for r in rows:
            age_s = (now - _as_aware(r["captured_at_utc"])).total_seconds()
            if age_s <= stale_s:
                fresh.append(r)
        if not fresh:
            continue

        # Require at least N distinct books across the legs (coarse consensus)
        books_present = {r["bookmaker"] for r in fresh}
        if len(books_present) < min_books:
            continue

        by_sel = {r["selection"]: r for r in fresh}

        # 3-way case
        if all(k in by_sel for k in ("home", "draw", "away")):
            prices = [by_sel["home"]["odds_decimal"], by_sel["draw"]["odds_decimal"], by_sel["away"]["odds_decimal"]]
            probs = de_vig_three_way(prices)
            if is_three_way_arb(prices):
                print(f"ARB (3-way): event={row['_id']} prices={prices}")
            loop = [("home", probs[0]), ("draw", probs[1]), ("away", probs[2])]
        # 2-way case
        elif all(k in by_sel for k in ("home", "away")):
            h, a = by_sel["home"]["odds_decimal"], by_sel["away"]["odds_decimal"]
            inv = [1.0 / h, 1.0 / a]
            s = sum(inv)
            probs = [x / s for x in inv]
            if is_two_way_arb(h, a):
                print(f"ARB (2-way): event={row['_id']} prices={[h, a]}")
            loop = [("home", probs[0]), ("away", probs[1])]
        else:
            continue

        for sel, p in loop:
            best = by_sel[sel]
            ev = ev_decimal(p, best["odds_decimal"])
            age_s = max(0.0, (now - _as_aware(best["captured_at_utc"])).total_seconds())
            if ev >= args.edge:
                doc = {
                    "event_key": row["_id"],
                    "market_uid": best.get("market_uid", "FT_1X2"),
                    "selection": sel,
                    "bookmaker": best["bookmaker"],
                    "odds": best["odds_decimal"],
                    "edge": ev,
                    "p_star": p,
                    "captured_at_utc": best["captured_at_utc"],
                    "age_s": age_s,
                    "computed_at_utc": now,
                }
                ev_coll.insert_one(doc)
                print(f"EV+ : event={row['_id']} sel={sel} {best['bookmaker']}@{best['odds_decimal']:.2f} EV={ev*100:.2f}% age={age_s:.0f}s")
                hits += 1

    print(f"Total EV hits stored: {hits}")


def cmd_book(args):
    p = "books.yaml"
    data = yaml.safe_load(open(p, "r", encoding="utf-8")) or {}
    for b in data.get("books", []):
        if b.get("key") == args.key:
            if args.action == "pause":
                b["enabled"] = False
                b["paused_reason"] = args.reason or "paused via CLI"
            elif args.action == "resume":
                b["enabled"] = True
                b["paused_reason"] = None
            break
    with open(p, "w", encoding="utf-8") as f:
        yaml.dump(data, f, sort_keys=False)
    print(f"{args.action}d {args.key}")


def cmd_robots_refresh(args):
    data = yaml.safe_load(open("books.yaml", "r", encoding="utf-8")) or {}
    db = get_db()
    for b in data.get("books", []):
        # Prefer registry.website; fallback to base_url
        base = (b.get("website") or b.get("base_url") or "").strip()
        if base:
            doc = fetch_and_store(db, base)
            print(f"Fetched robots for {doc['host']}")


def cmd_metrics_odds_age(args):
    db = get_db()
    coll = db.get_collection("quotes_snapshots")
    now = datetime.now(timezone.utc)

    buckets = {"0-60s": 0, "1-5m": 0, "5-30m": 0, "30m-2h": 0, ">2h": 0}

    for doc in coll.find({}, {"captured_at_utc": 1}).limit(10000):
        age = (now - _as_aware(doc["captured_at_utc"])).total_seconds()
        if age <= 60:
            buckets["0-60s"] += 1
        elif age <= 300:
            buckets["1-5m"] += 1
        elif age <= 1800:
            buckets["5-30m"] += 1
        elif age <= 7200:
            buckets["30m-2h"] += 1
        else:
            buckets[">2h"] += 1
    print("Odds age histogram:", buckets)


def cmd_settings(args):
    from dataclasses import asdict
    from .config import SETTINGS as _S
    for k, v in asdict(_S).items():
        print(f"{k} = {v}")


def cmd_stats(args):
    """Quick DB stats for quotes_snapshots (counts + last 3 docs)."""
    db = get_db()
    coll = db.get_collection("quotes_snapshots")
    total = coll.estimated_document_count()
    print(f"quotes_snapshots: {total}")
    if total == 0:
        return
    pipeline = [
        {"$group": {"_id": {"book": "$bookmaker", "market": "$market_uid"}, "n": {"$sum": 1}}},
        {"$sort": {"_id.book": 1, "_id.market": 1}},
    ]
    rows = list(coll.aggregate(pipeline))
    print("by book / market:")
    for r in rows:
        print(f"  {r['_id']['book']:<10} {r['_id']['market']:<10} n={r['n']}")
    print("\nlatest 3 docs:")
    for doc in coll.find({}, {"_id": 0}).sort("captured_at_utc", -1).limit(3):
        slim = {k: doc.get(k) for k in ("captured_at_utc","bookmaker","event_key","market_uid","selection","odds_decimal","param","source_url")}
        pprint(slim)


# ------------------- Entry ------------------- #

def main(argv=None):
    p = argparse.ArgumentParser(prog="bettingos")
    sub = p.add_subparsers(dest="cmd")

    s = sub.add_parser("init-db"); s.set_defaults(func=cmd_init_db)

    s = sub.add_parser("proto-scrape")
    s.add_argument("book")
    s.add_argument("--browser", action="store_true", help="Use generic browser harvester for this book")
    s.set_defaults(func=cmd_proto_scrape)

    s = sub.add_parser("scheduler"); s.set_defaults(func=cmd_scheduler)

    s = sub.add_parser("ev-scan"); s.add_argument("--edge", type=float, default=0.02); s.set_defaults(func=cmd_ev_scan)

    s = sub.add_parser("ev-scan-xbook"); s.add_argument("--edge", type=float, default=0.02); s.set_defaults(func=cmd_ev_scan_xbook)

    s = sub.add_parser("book"); s.add_argument("action", choices=["pause", "resume"]); s.add_argument("key"); s.add_argument("--reason"); s.set_defaults(func=cmd_book)

    s = sub.add_parser("robots-refresh"); s.set_defaults(func=cmd_robots_refresh)

    s = sub.add_parser("metrics-odds-age"); s.set_defaults(func=cmd_metrics_odds_age)

    s = sub.add_parser("settings"); s.set_defaults(func=cmd_settings)

    s = sub.add_parser("stats"); s.set_defaults(func=cmd_stats)

    args = p.parse_args(argv)
    if not hasattr(args, "func"):
        p.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
